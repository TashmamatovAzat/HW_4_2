from django.contrib import admin

from .models import Item, Purchase

admin.site.register(Item)

admin.site.register(Purchase)
